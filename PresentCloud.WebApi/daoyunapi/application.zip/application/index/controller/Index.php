<?php
namespace app\index\controller;
use think\Controller;
use think\Db;
use app\api\controller\Base;
use think\Loader;

use PHPExcel;
use PHPExcel_IOFactory;
use PHPExcel_Cell;

class Index extends Base
{
    public function index()
    {
    	var_dump('heelo');
    }

    public  static function importexcel($path){
        Loader::import('PHPExcel.PHPExcel');
        Loader::import('PHPExcel.PHPExcel.PHPExcel_IOFactory');
        Loader::import('PHPExcel.PHPExcel.PHPExcel_Cell');
        // 判断文件是什么格式
        $type = pathinfo($path);
        $type = strtolower($type["extension"]);

        if ($type == 'xlsx') {
            $type = 'Excel2007';
        } elseif ($type == 'xls') {
            $type = 'Excel5';
        }
        //最长执行时间,php默认为30秒,这里设置为0秒的意思是保持等待直到程序执行完成
        ini_set('max_execution_time', '0');
        // 判断使用哪种格式
        $objReader = PHPExcel_IOFactory::createReader($type);
        $objPHPExcel = $objReader->load($path);

        $sheet = $objPHPExcel->getSheet(0);//获取工作薄
        // 取得总行数
        $highestRow = $sheet->getHighestRow();
        // 取得总列数
        $highestColumn = $sheet->getHighestColumn();
        //循环读取excel文件,读取一条,插入一条
        $data=array();
        //从第一行开始读取数据  这里类似冒泡算法
        for($j=1;$j<=$highestRow;$j++){
            //从A列读取数据
            for($k='A';$k<=$highestColumn;$k++){
                // 读取单元格
                $data[$j][]=$objPHPExcel->getActiveSheet()->getCell("$k$j")->getValue();
            }
        }
        return $data;
    }
}
